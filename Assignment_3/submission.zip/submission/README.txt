Assignment 3
There are 2 parts and 2 scripts
A3_02_07_2022.py and part2.py

A3_02_07_2022.py contains the main script and contains the anwsers to part 3 to 5 for the homework assignment
part2.py contains the anwser to part 2 of the homework.

part2.py is just a construction file for part 2. matplotlob's 3d module does not execute on tux the graph for the script has been added to the submission pdf file.
A3_02_07_2022.py to execute properly we need to have the datasets 'mcpd_augmented.csv' and 'KidCreative.csv' in the same folder as the script.

All of the execution is handeled inside of the script. To run use python3 in tux.
ex. python3 A3_02_07_2022.py